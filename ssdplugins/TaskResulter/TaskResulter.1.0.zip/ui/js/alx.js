
	var base_url = "../plugin/rest/taskResults/";
	var config = { headers: { 'X-XSRF-TOKEN': PluginHelper.getCsrfToken() }};
	var app = angular.module('taskResulter', []);
	
	app.controller('taskResulterController', function($scope, $http) {
		
		var noTaskSelectedMessage = "No task result selected ...";
		
		//Lets not show result panels initially
		this.showMainPanel = false;
		this.showPartitionedResults = false;
		this.showEstimates = false;
		
		
		
		$http.get(base_url + 'getApplications', config).success(function(data, status, headers, config) {
			var dataSize = data.shift();
			console.log("Application count: "+ dataSize.appCount);
			$scope.appData = data;
			$scope.appData.unshift({"appName":"NA", "displayAppName":"No application selected ..."});
		});

		
		$http.get(base_url+'getList', config).success(function(data, status, headers, config) {
					
			if(data.message.length > 0) {
				$scope.resultList = data.message;
				$scope.resultList.unshift([noTaskSelectedMessage, noTaskSelectedMessage]);
			} else { //not task results in the system at all
				$scope.resultList = [];
				$scope.resultList.push(["No task results", "No task results"]);
			}
			$scope.showInvokeButton = false;
		});
		
		// run when application drop down changes
		$scope.updateResultList = function() {
			var noTaskSelectedMessage = "No task result selected ...";
			
			if($scope.selectedApplication !== "NA") {
				config.params = {appName: $scope.selectedApplication}
			}
				
			$http.get(base_url+'getList', config).success(function(data, status, headers, config) {
						
				if(data.message.length == 0 ) { // no task results returned
					
					if($scope.selectedApplication === "NA") { // no application was selected
						var noResultsMessage = "No task results";
					} else {//some application was selected
						var noResultsMessage = "No task results for application";
					}
					
					$scope.resultList = [];
					$scope.resultList.push([noResultsMessage, noResultsMessage]);
					$scope.selectedTaskResult = noResultsMessage;
					$scope.showInvokeButton = false;
					$scope.showMainPanel = false;
					$scope.showPartitionedResults = false;
				} else {// some task results were returned
					
					$scope.resultList = data.message;
					if($scope.selectedApplication === "NA") { // no application was selected
						$scope.resultList.unshift([noTaskSelectedMessage, noTaskSelectedMessage]);
					}
					$scope.selectedTaskResult = data.message[0][0];
					$scope.showInvokeButton = true;
				}	
		    });
		}
	    
	    $scope.calcualteResults = function () {
	    	
	    	config.params = {taskResultName: $scope.selectedTaskResult}; 
	    	
	    	$http.get(base_url+'getTaksResultCalcualtion', config).success(function(data, status, headers, config) {
	    			    		
	    		$scope.resultName = data.resultName;
	    		$scope.status = data.status;
	    		$scope.started = data.started;
	    		$scope.finished = data.finished;
	    		$scope.totalr = data.total;
                $scope.optimized = data.optimized;
                $scope.ignored = data.ignored;
                $scope.updated = data.updated;
                $scope.speed = data.speed;
                $scope.procDuration = data.durationString;
	    		
                //we can show the main result panel now
                $scope.showMainPanel = true; 
                $scope.showInvokeButton = true;
	    		
	    		if (data.partialResults === null || data.partialResults.length === 0) {
	    			$scope.showPartitionedResults = false;
                } else {
                	$scope.partitions = data.partialResults;
                	$scope.showPartitionedResults = true;
                }
	    		
	    		$scope.showEstimates = false;
               	if(data.estimatedTimeLeft !== null) {
               		$scope.estimatedTimeLeft = data.estimatedTimeLeft;
               		$scope.showEstimates = true;
               	}
               	
               	$scope.rawData = data;
	    		
	    	});
	    }		
	});
	
	


